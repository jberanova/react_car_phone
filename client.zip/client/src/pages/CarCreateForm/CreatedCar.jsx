import { useParams, Link } from "react-router-dom";
import "./CarCreateForm.css";

export default function CreatedCar() {
  const { id } = useParams();

  return (
    <>
      <p>Car was created: {id}</p>
      <Link to={`/car/${id}`}>
        <p>View car</p>
      </Link>
      <Link to={`/`}>
        <p>Go back</p>
      </Link>
    </>
  );
}
