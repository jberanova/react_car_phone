import { Link } from "react-router-dom";
import PhoneLink from "./PhoneLink";
import { useState, useEffect } from "react";
import { getAllPhones } from "../../models/Phone";
import "./PhoneList.css";

export default function PhoneList() {
  const [phones, setPhones] = useState();
  const [loaded, setLoaded] = useState(false);

  const load = async () => {
    const data = await getAllPhones();
    if (data.status === 500 || data.status === 404) return setLoaded(null);
    if (data.status === 200) {
      setPhones(data.payload);
      setLoaded(true);
    }
  };

  useEffect(() => {
    load();
  }, []);

  if (loaded === null) {
    return (
      <>
        <p>Phones not found</p>
      </>
    );
  }

  if (!loaded) {
    return (
      <>
        <p>Phones are loading</p>
      </>
    );
  }

  return (
    <>
    <div className="phonelist">
      <h1>Phone list</h1>
      <p>Click on the phone name to view the phone</p>
      {
        phones.map((phone, index) => (
            <PhoneLink key={index} name={phone.name} id={phone._id} />
        ))
      }
      <Link to={"/"}>
        <p>Go back</p>
      </Link>
    </div>
    </>
  );
}
