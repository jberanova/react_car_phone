import { Link } from "react-router-dom"
import "./PhoneList.css"

export default function PhoneLink(props) {

    return (
        <>
            <p className="phonename">Name: {props.name}</p>
            <Link className="viewphone" to={`/phone/${props.id}`}>
                <p>View phone</p>
            </Link>
        </>
    )
}