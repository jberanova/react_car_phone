import { Link, useParams, useNavigate } from "react-router-dom";
import { getPhoneById, deletePhone } from "../../models/Phone";
import { useEffect, useState } from "react";
import "./PhoneView.css"

export default function PhoneView() {
  const { id } = useParams();
  const [phone, setPhone] = useState();
  const [loaded, setLoaded] = useState();
  const [formData, setFormData] = useState();
  const [info, setInfo] = useState();
  const navigate = useNavigate();

  const load = async () => {
    const data = await getPhoneById(id);
    if (data.status === 500 || data.status === 404) return setLoaded(null);
    if (data.status === 200) {
      setPhone(data.payload);
      setLoaded(true);
    }
  }

  const handleDelete = async (e) => {
    e.preventDefault();
    if (formData === phone.name) {
      const result = await deletePhone(id);
      if (result.status === 200) {
        redirect(id);
      } else {
        setInfo(result.msg);
      }
    } else {
      setInfo("Wrong phone name");
    }
  }

  const handleChange = (e) => {
    setFormData(e.target.value);
  }

  const redirect = (id) => {
    return navigate(`/deletedphone/${id}`);
  }


  useEffect(() => {
    load();
  }, []);

  if (loaded === null) {
    return (
      <>
        <p>Phone not found</p>
      </>
    )
  }

  if (!loaded) {
    return (
      <>
        <p>Loading phone...</p>
      </>
    )
  }

  return (
    <>
      <h1>Phone view</h1>
      <p className="phoneP">Phone id: {id}</p>
      <p>Phone name: {phone.name}</p>
      <p>Phone legs: {phone.legs}</p>
      <p>Phone color: {phone.color}</p>
      <form>
        <p>Napište jméno kočky pro smazání kočky</p>
        <input type="text" placeholder={phone.name} onChange={handleChange}/>
        <button onClick={handleDelete}>Delete phone</button>
        <p>{info}</p>
      </form>
      <Link to={`/updatephone/${id}`}>
        <p>Update phone</p>
      </Link>
      <Link to={"/"}>
        <p>Go back</p>
      </Link>
    </>
  );
}
