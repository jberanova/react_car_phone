import { BrowserRouter, Routes, Route } from "react-router-dom";
import MainPage from "./MainPage/MainPage";
import CarView from "./CarView/CarView";
import CarList from "./CarList/CarList";
import CarCreateForm from "./CarCreateForm/CarCreateForm";
import CarUpdateForm from "./CarUpdateForm/CarUpdateForm";
import CreatedCar from "./CarCreateForm/CreatedCar";
import CarDeleted from "./CarView/CarDeleted";

import PhoneView from "./PhoneView/PhoneView";
import PhoneList from "./PhoneList/PhoneList";
import PhoneCreateForm from "./PhoneCreateForm/PhoneCreateForm";
import PhoneUpdateForm from "./PhoneUpdateForm/PhoneUpdateForm";
import CreatedPhone from "./PhoneCreateForm/CreatedPhone";
import PhoneDeleted from "./PhoneView/PhoneDeleted";

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/car/:id" element={<CarView />} />
        <Route path="/cars" element={<CarList />} />
        <Route path="/createcar" element={<CarCreateForm />} />
        <Route path="/updatecar/:id" element={<CarUpdateForm />} />
        <Route path="/createdcar/:id" element={<CreatedCar />} />
        <Route path="/deletedcar/:id" element={<CarDeleted />} />
        <Route path="/" element={<MainPage />} />
        <Route path="/phone/:id" element={<PhoneView />} />
        <Route path="/phones" element={<PhoneList />} />
        <Route path="/createphone" element={<PhoneCreateForm />} />
        <Route path="/updatephone/:id" element={<PhoneUpdateForm />} />
        <Route path="/createdphone/:id" element={<CreatedPhone />} />
        <Route path="/deletedphone/:id" element={<PhoneDeleted />} />
      </Routes>
    </BrowserRouter>
  );
}
