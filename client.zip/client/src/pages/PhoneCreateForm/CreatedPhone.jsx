import { useParams, Link } from "react-router-dom";
import "./PhoneCreateForm.css";

export default function CreatedPhone() {
  const { id } = useParams();

  return (
    <>
      <p>Phone was created: {id}</p>
      <Link to={`/phone/${id}`}>
        <p>View phone</p>
      </Link>
      <Link to={`/`}>
        <p>Go back</p>
      </Link>
    </>
  );
}
