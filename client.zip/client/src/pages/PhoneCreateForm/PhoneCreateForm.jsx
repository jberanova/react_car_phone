import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { createPhone } from "../../models/Phone";
import "./PhoneCreateForm.css";

export default function PhoneCreateForm() {
  //useState - vytvoreni promenne v reactu
  // nazev promenne, setter       useState(default_hodnota)
  const [formData, setFormData] = useState();
  const [info, setInfo] = useState();
  const navigate = useNavigate();

  const postForm = async () => {
    const phone = await createPhone(formData);
    if (phone.status === 201) {
      redirectToSuccessPage(phone.payload._id);
    } else {
      setInfo(phone.msg);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePost = (e) => {
    e.preventDefault();
    postForm();
  };

  const redirectToSuccessPage = (id) => {
    return navigate(`/createdphone/${id}`);
  };

  return (
    <>
    <div className="createpage">
      <h1>Phone create form</h1>

      <form>
        <input
          className="input"
          type="text"
          required
          name="name"
          placeholder="Enter name"
          onChange={(e) => handleChange(e)}
        />
        <input
        className="input"
          type="number"
          required
          name="legs"
          placeholder="Enter number of legs"
          onChange={(e) => handleChange(e)}
        />
        <input
        className="input"
          type="text"
          required
          name="color"
          placeholder="Enter color"
          onChange={(e) => handleChange(e)}
        />
        <button className="button" onClick={handlePost}>Create phone</button>
      </form>
      <p>{info}</p>
      <Link className="back" to={"/"}>
        <p>Go back</p>
      </Link>
    </div>
    </>
  );
}
