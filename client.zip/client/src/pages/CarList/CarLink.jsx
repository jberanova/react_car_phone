import { Link } from "react-router-dom"
import "./CarList.css"

export default function CarLink(props) {

    return (
        <>
            <p className="carname">Name: {props.name}</p>
            <Link className="viewcar" to={`/car/${props.id}`}>
                <p>View car</p>
            </Link>
        </>
    )
}