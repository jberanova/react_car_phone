import { Link, useNavigate, useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { updatePhone, getPhoneById } from "../../models/Phone";

export default function PhoneUpdateForm() {
  const { id } = useParams();  
  const [formData, setFormData] = useState();
  const [info, setInfo] = useState();
  const [loaded, setLoaded] = useState();
  const [phone, setPhone] = useState();
  const navigate = useNavigate();

  const load = async () => {
    const data = await getPhoneById(id);
    if (data.status === 500 || data.status === 404) return setLoaded(null);
    if (data.status === 200) {
      setPhone(data.payload);
      setLoaded(true);
    }
  }

  const postForm = async () => {
    const phone = await updatePhone(id, formData);
    if (phone.status === 200) {
      redirectToSuccessPage(phone.payload._id);
    } else {
      setInfo(phone.msg);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePost = (e) => {
    e.preventDefault();
    postForm();
  };

  const redirectToSuccessPage = (id) => {
    return navigate(`/phone/${id}`);
  };

  useEffect(() => {
    load();
  }, []);

  if (loaded === null) {
    return (
      <>
        <p>Phone not found</p>
      </>
    )
  }

  if (!loaded) {
    return (
      <>
        <p>Loading phone...</p>
      </>
    )
  }

  return (
    <>
      <h1>Phone update form</h1>

      <form>
        <input
          type="text"
          required
          name="name"
          placeholder="Enter name"
          defaultValue={phone.name}
          onChange={(e) => handleChange(e)}
        />
        <input
          type="number"
          required
          name="legs"
          placeholder="Enter number of legs"
          defaultValue={phone.legs}
          onChange={(e) => handleChange(e)}
        />
        <input
          type="text"
          required
          name="color"
          placeholder="Enter color"
          defaultValue={phone.color}
          onChange={(e) => handleChange(e)}
        />
        <button onClick={handlePost}>Update phone</button>
      </form>
      <p>{info}</p>
      <Link to={"/"}>
        <p>Go back</p>
      </Link>
    </>
  );
}
