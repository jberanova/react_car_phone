import "./MainPage.css";
import { Link } from "react-router-dom";

export default function MainPage() {
  return (
    <>
    <div className="car">
      <h1>Cars</h1>
      <h2>Welcome to the Car and Phone App!</h2>
      <h3>Choose an action:</h3>
    

      <Link className="createdcar" to={"/createcar"}>
        <p>Car create form</p>
      </Link>
      
      <Link className="listcar" to={"/cars"}>
        <p>Car list</p>
      </Link>

      <Link className="createdcar" to={"/createphone"}>
        <p>Phone create form</p>
      </Link>

      <Link className="listcar" to={"/phones"}>
        <p>Phone list</p>
      </Link>
    </div>
    </>
  );
}
